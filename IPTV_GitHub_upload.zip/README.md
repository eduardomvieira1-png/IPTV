# Playlist IPTV para VLC

Arquivo: `IPTV_GitHub.m3u`

## Como usar
1. Envie `IPTV_GitHub.m3u` para um repositório GitHub.
2. Para baixar, abra o arquivo no GitHub e clique em **Raw**.
3. Copie a URL da página Raw e, no VLC, use **Mídia → Abrir localização de rede** para colar a URL.

A playlist contém 68 entradas de canais. O GitHub apenas hospeda a lista; ele não hospeda nem garante o funcionamento dos fluxos M3U8. A reprodução depende de os endereços continuarem ativos e de você ter autorização para acessá-los.
